package com.example.eduplay

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Bernyanyi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bernyanyi)
    }
}