package com.example.eduplay

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView

class BerhitungActivity_A : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_berhitung_activity)

        val imageButton: ImageView = findViewById(R.id.btnArah)

        imageButton.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        when(v.id){
            R.id.btnArah -> {
                val intent = Intent(this@BerhitungActivity_A, BerhitungActivity_B::class.java)
                startActivity(intent)
            }
        }
    }
}